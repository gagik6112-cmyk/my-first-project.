export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ ok: false, error: 'Method not allowed' });
    return;
  }

  const { TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID } = process.env;
  const isTelegramReady = TELEGRAM_BOT_TOKEN && TELEGRAM_CHAT_ID;

  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const raw = Buffer.concat(chunks).toString('utf8');

  let payload = {};
  try {
    payload = JSON.parse(raw || '{}');
  } catch (e) {
    // try parse urlencoded
    payload = Object.fromEntries(new URLSearchParams(raw));
  }

  const { formName = 'unknown', fields = {} } = payload;

  // Build a message
  const lines = [
    `🦊 Лисья Нора — новая заявка (${formName})`,
    ...Object.entries(fields).map(([k,v]) => `• ${k}: ${v}`)
  ];
  const text = lines.join('\n');

  if (isTelegramReady) {
    const telegramURL = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
    const resp = await fetch(telegramURL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text })
    });
    const data = await resp.json();
    if (!data.ok) {
      res.status(500).json({ ok: false, error: 'Telegram send failed', data });
      return;
    }
  }

  res.status(200).json({ ok: true, delivered: Boolean(isTelegramReady) });
}
