# Лисья Нора — многостраничный сайт (Vite + React)

## Локальный запуск
```bash
npm install
npm run dev
```

## Деплой на Vercel
1. Импортируйте репозиторий в Vercel.
2. В Project Settings → Environment Variables добавьте:
   - `TELEGRAM_BOT_TOKEN` — токен вашего бота
   - `TELEGRAM_CHAT_ID` — chat_id, куда слать заявки
3. Vercel соберёт проект командой `npm run build` (см. `vercel.json`).  
   Формы отправляют POST на `/api/submit` и придут в Telegram.

## Деплой на Netlify
1. Подключите репозиторий в Netlify.
2. Build Command: `npm run build`, Publish directory: `dist` (см. `netlify.toml`).
3. Формы отмечены атрибутом `data-netlify="true"`, Netlify их перехватит автоматически.
   В панели Netlify → Forms появятся заявки.

## Как работают формы
- **Netlify Forms**: требуется только `data-netlify="true"` и `name` у формы + скрытое поле `form-name`.
- **Vercel**: запросы уходят в `/api/submit` (см. `api/submit.js`). Вы можете поменять логику отправки (например, отправку email через сторонний сервис).

Обновите контакты/адреса/логотип в `src/App.jsx`.
